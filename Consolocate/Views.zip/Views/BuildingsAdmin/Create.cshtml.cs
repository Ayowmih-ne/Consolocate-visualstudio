using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Consolocate.Views.BuildingsAdmin
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
