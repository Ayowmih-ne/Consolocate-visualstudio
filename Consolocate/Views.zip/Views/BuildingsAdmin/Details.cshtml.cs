using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Consolocate.Views.BuildingsAdmin
{
    public class DetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
