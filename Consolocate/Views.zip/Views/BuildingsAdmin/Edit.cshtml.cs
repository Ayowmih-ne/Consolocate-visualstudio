using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Consolocate.Views.BuildingsAdmin
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
